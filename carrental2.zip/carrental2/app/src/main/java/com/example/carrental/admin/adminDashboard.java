package com.example.carrental.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.carrental.R;

public class adminDashboard extends AppCompatActivity {
TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        textView = findViewById(R.id.name);

        Intent intent = getIntent();
        String v = intent.getStringExtra("name");

        textView.setText(String.valueOf(v));
    }

    public void logOut(View view) {

        Intent intent = new Intent(getApplicationContext(),adminLogin.class);
        startActivity(intent);
    }
}
