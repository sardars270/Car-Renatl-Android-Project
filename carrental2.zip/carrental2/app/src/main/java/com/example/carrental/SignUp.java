package com.example.carrental;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatActivity {
    RequestQueue requestQueue;
    private StringRequest request;
    String insertUrl = "http://thind.atwebpages.com/index.php";

    EditText nm,ema,ps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        nm=findViewById(R.id.name);
        ema=findViewById(R.id.email);
        ps=findViewById(R.id.pass);
        requestQueue = Volley.newRequestQueue(this);
    }


    public void backtologin(View view) {
        Intent intent=new Intent(getApplicationContext(),clientLogIn.class);
        startActivity(intent);
    }

    public void register(View view) {
        request=new StringRequest(Request.Method.POST, insertUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);

                    if(jsonObject.names().get(0).equals("error"))
                    {
                        Toast.makeText(getApplicationContext(), "ERROR : " + jsonObject.getString("error"), Toast.LENGTH_SHORT).show();

                    }
                    else {
                        if (jsonObject.getString("value").equals("true")) {
                            Toast.makeText(getApplicationContext(), "Registration Succesfull. LogIn Now...", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(getApplicationContext(),clientLogIn.class);
                            startActivity(intent);
                        }  else {
                            Toast.makeText(getApplicationContext(), "Registration Unsuccesfull ", Toast.LENGTH_LONG).show();

                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> hashMap = new HashMap<String, String>();
                hashMap.put("function","signup");
                hashMap.put("email",ema.getText().toString());
                hashMap.put("password",ps.getText().toString());
                hashMap.put("name",nm.getText().toString());

                return hashMap;
            }
        };
        requestQueue.add(request);
    }
}
