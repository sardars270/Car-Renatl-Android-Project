package com.example.carrental;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.carrental.admin.adminLogin;

public class MainActivity extends AppCompatActivity {
TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.name);

        Intent intent = getIntent();
        String v = intent.getStringExtra("name");

        textView.setText(String.valueOf(v));
    }

    public void enter(View view) {
        Intent intent =new Intent(getApplicationContext(),clientLogIn.class);
        startActivity(intent);
    }

    public void adminEnter(View view) {
        Intent intent=new Intent(getApplicationContext(), adminLogin.class);
        startActivity(intent);
    }

    public void logOut(View view) {

        Intent intent = new Intent(getApplicationContext(),clientLogIn.class);
        startActivity(intent);
    }
}
